package com.bean_abdulBasit_240604;
import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.bean.ViewScoped;
import javax.faces.component.UIComponent;
import javax.faces.component.UIInput;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;
import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.validations_abdulBasit_240604.Utility;

@ManagedBean
@RequestScoped
public class Student implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */	
//	private static Pattern passwordPattern = Pattern.compile("^(?=.*[0-9])"
//            + "(?=.*[a-z])(?=.*[A-Z])"
//            + "(?=.*[@#$%^&+=])"
//            + "(?=\\S+$).{8,20}$");
	
	@NotNull(message = "Name can't be null")
	private String name;
	
	@NotNull(message = "userName can't be null")
	private String userName;
	
	@NotNull(message = "password can't be null")
	private String password;
	
	@NotNull(message = "rePassword can't be null")
	private String rePassword;
	
	@NotNull(message = "gender can't be null")
	private String gender;
	
	@NotNull(message = "programmingSkills can't be null")
	private List<String> programmingSkills;
	
	@NotNull(message = "contact can't be null")
	@Pattern(regexp="\\(\\d{3}\\)\\d{3}-\\d{4}")
	private String contact;
	
	@NotNull(message = "email can't be null")
	private String email;
	
	@NotNull(message = "college can't be null")
	private String college;
	
	private String otherCollege;

	private Utility utility; 
	
	@NotNull
	private UIInput passwordComponent;
	
	public UIInput getPasswordComponent() {
		return passwordComponent;
	}
	public void setPasswordComponent(UIInput passwordComponent) {
		this.passwordComponent = passwordComponent;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}
	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	/**
	 * @return the rePassword
	 */
	public String getRePassword() {
		return rePassword;
	}
	/**
	 * @param rePassword the rePassword to set
	 */
	public void setRePassword(String rePassword) {
		this.rePassword = rePassword;
	}
	/**
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}
	/**
	 * @param gender the gender to set
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}
	/**
	 * @return the programmingSkills
	 */
	public List<String> getProgrammingSkills() {
		return programmingSkills;
	}
	/**
	 * @param programmingSkills the programmingSkills to set
	 */
	public void setProgrammingSkills(List<String> programmingSkills) {
		this.programmingSkills = programmingSkills;
	}
	/**
	 * @return the contact
	 */
	public String getContact() {
		return contact;
	}
	/**
	 * @param contact the contact to set
	 */
	public void setContact(String contact) {
		this.contact = contact;
	}
	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @return the college
	 */
	public String getCollege() {
		return college;
	}
	/**
	 * @param college the college to set
	 */
	public void setCollege(String college) {
		this.college = college;
	}
	
	public String getOtherCollege() {
		return otherCollege;
	}
	public void setOtherCollege(String otherCollege) {
		this.otherCollege = otherCollege;
	}
	
	public String submitButton() throws Exception {
		System.out.println("Submitting details:::");
		
		String pwd1 = getPassword();
		String pwd2 = getRePassword();
		
	
		
		if (!pwd1.equals(pwd2)) {
			displayMessage("validation failed for the password:::");
			//clearField();
			return null;
			//throw new Exception("Invalid format....");
		}
		return "response.xhtml?faces-redirect=true";
	}
	private void displayMessage(String message) {
		FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, message, null));
	}
	
	public void clearField() {
		name = null;
		userName = null;
		password = null;
		rePassword = null;
		gender = null;
		programmingSkills = null;
		contact = null;
		college = null;
		email = null;
	}
	
//	@Override
//	public void validate(FacesContext context, UIComponent comp, Object value) throws ValidatorException {
//		//UIInput pwd2 = (UIInput) comp.findComponent(rePassword);
//		//UIInput pwd21 = (UIInput) comp.getAttributes().get(rePassword);
//		Map<String,UIComponent> pwd24 = comp.getFacets();
//		UIInput pwd23 = (UIInput) comp.getFacets();
//		
//		
//		String pwd = (String) value;
//		if (!Utility.validatePassword(pwd)) {
//			String pwd1 = getPassword();
//			String pwd20 = getRePassword();
//			FacesMessage msg = new FacesMessage("Password format invalid or not same ");
//			throw new ValidatorException(msg);
//		}
//	}

}
