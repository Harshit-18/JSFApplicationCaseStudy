package com.validations_abdulBasit_240604;

import java.util.regex.Pattern;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.component.UIComponent;
import javax.faces.component.UIInput;
import javax.faces.context.FacesContext;
import javax.faces.validator.FacesValidator;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

import com.bean_abdulBasit_240604.Student;

@FacesValidator("passwordValidator")
public class Utility implements Validator{
	
	private Student student;
	
	private static Pattern passwordPattern = Pattern.compile("^(?=.*[0-9])"
            + "(?=.*[a-z])(?=.*[A-Z])"
            + "(?=.*[@#$%^&+=])"
            + "(?=\\S+$).{8,20}$");	
	public static boolean validatePassword(String passwordPatt) {		
		return passwordPattern.matcher(passwordPatt).matches();
		
	}

	@Override
	public void validate(FacesContext context, UIComponent comp, Object value) throws ValidatorException {
		//UIInput passwordComponent = (UIInput) comp.getAttributes().get("passwordComponent");
		//String password = (String) passwordComponent.getSubmittedValue();
		 
		System.out.println("validate......>>>>>");
		String rePassword = (String) value;
		if (!Utility.validatePassword(rePassword)) {
			//student.clearField();
			throw new ValidatorException(createError("Password do not match"));
		}
		
	}
	private FacesMessage createError(String message) {
		return new FacesMessage(FacesMessage.SEVERITY_ERROR, message, null);
	}
	
//	public void validate(FacesContext context, UIComponent comp,
//			Object value) {
//		System.out.println("inside validate method");
//		String password = (String) value;
//		if (!validatePassword(password)) {
//			FacesMessage msg = new FacesMessage("Password Format: At least one upper case, At least one lower case English letter"
//					+ "At least one lower case English letter" + "At least one digit" 
//					+ "At least one special character" + "Minimum eight in length");
//			context.addMessage(comp.getClientId(context), msg);
//		}
//	}

}
